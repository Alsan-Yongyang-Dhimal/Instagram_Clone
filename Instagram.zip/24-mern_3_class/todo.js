// Load the data from LocalStorage

const todoListElement = document.querySelector("#todo-list");
let todoListJSONData = localStorage.getItem("data");

let todoListData; // This is now JS Object

if ( todoListJSONData == null ) {
    todoListData = [];
} else {
    todoListData = JSON.parse(todoListJSONData);
}


const formElement = document.querySelector("#todo-form");
const formInput = document.querySelector("#todo-input");

formElement.addEventListener('submit', (e) =>{
    e.preventDefault();
    const inputValue = formInput.value;
    if (inputValue.trim() == "") {
        return;
    }

    addNewTodo(formInput.value);
    formInput.value = "";
})

function render() {

    // Save the data
    // Convert javascript object to JSON
    const todoListInJSONForm = JSON.stringify(todoListData);
    localStorage.setItem("data", todoListInJSONForm)
    

    todoListElement.innerHTML = "";

    if ( todoListData.length == 0) {
        // Show empty picture
        const imageElement = document.createElement("img");
        imageElement.setAttribute("src","./empty_notes_ill.svg");
        imageElement.setAttribute("alt", "Empty todos");
        imageElement.setAttribute("height", "100");
        imageElement.setAttribute("width", "200");
        
        const emptyContainerTitleElement = document.createElement("h4");
        emptyContainerTitleElement.id = "empty-container-title";
        emptyContainerTitleElement.textContent = "No todos for today";

        const emptyContainerElement = document.createElement("div");
        emptyContainerElement.id = "empty-container";
        emptyContainerElement.appendChild(imageElement);
        emptyContainerElement.appendChild(emptyContainerTitleElement);

        todoListElement.appendChild(emptyContainerElement);
        return;
    }   
    
    for ( const todo of todoListData ) {
        const todoElement = document.createElement("div");

        todoElement.className = "todo-element";

        const titleElement = document.createElement("span");
        titleElement.textContent = todo.title;
        todoElement.appendChild(titleElement);

        if ( todo.isCompleted == true ) {
            titleElement.style.textDecoration = "line-through";
            titleElement.style.color = "gray";
        }
        
        const toggleCompletedElement = document.createElement("button");
        toggleCompletedElement.className = "todo-action todo-action-completed";
        toggleCompletedElement.textContent = "✔";
        todoElement.appendChild(toggleCompletedElement);

        const deleteButtonElement = document.createElement("button");
        deleteButtonElement.className = "todo-action todo-action-delete";
        deleteButtonElement.textContent = "⤬";
        todoElement.appendChild(deleteButtonElement);
        
        todoListElement.appendChild(todoElement);

        toggleCompletedElement.addEventListener('click', () => {
            markCompleted(todo.id);
        })

        deleteButtonElement.addEventListener('click', () => {
            deleteTodo(todo.id);
        });
    }
}

render();

function addNewTodo(title) {
    
    todoListData.push({
        title: title,
        isCompleted: false,
        id: Math.random().toString(36).slice(2),
    });
    
    render();
}

function deleteTodo(deleteId) {
    todoListData = todoListData.filter(todo => todo.id !== deleteId)
    render();
}

function markCompleted(todoId) {
    for ( const todo of todoListData ) {
        if ( todo.id == todoId ) {
            todo.isCompleted = !todo.isCompleted;
        }
    }
    render();
}