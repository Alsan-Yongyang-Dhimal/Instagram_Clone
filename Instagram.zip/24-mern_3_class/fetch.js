// fetch("https://jsonplaceholder.typicode.com/todos")
//     .then(data => data.json())
//     .then(data => {
//         console.log(data);
//     })

async function getData() {
    const rawData = await fetch("https://jsonplaceholder.typicode.com/todos");
    const todos = await rawData.json();

    const todoList = document.getElementById("todo-list");

    for ( const todo of todos ) {
        const todoTitle = todo.title;
        const todoCompleted = todo.completed;

        // Creat eelement
        // Give props
        // Append child

        const todoElement = document.createElement("div");
        todoElement.textContent = todoTitle;
        if ( todoCompleted === true ) {
            todoElement.className = "completed";
        }
        
        todoList.appendChild(todoElement);
    }
}

getData();