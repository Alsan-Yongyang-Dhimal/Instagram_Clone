const main = document.querySelector("#main");
const cover = document.querySelector("#cover");

main.addEventListener('mousemove', (e) => {
    cover.style.background = `radial-gradient(circle at ${e.x}px ${e.y}px, transparent, #000 160px)`;
})