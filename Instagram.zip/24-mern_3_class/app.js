const main = document.querySelector("#main");

main.addEventListener('click', (e) => {
    const circle = document.createElement("div");
    circle.className = "circle";

    circle.style.top = `${e.y}px`;
    circle.style.left = `${e.x}px`;

    main.appendChild(circle);

    setTimeout(() => {
        circle.remove();
    },1000)
});