import { IoMdHeartEmpty } from "react-icons/io";
import instagramLogo from "../assets/instagram_logo.png";

// Icons
import { GoHomeFill } from "react-icons/go";
import { IoSearchOutline } from "react-icons/io5";
import { LuCompass } from "react-icons/lu";
import { RiMessengerLine } from "react-icons/ri";
import { TbSquareRoundedPlus } from "react-icons/tb";
import { RxHamburgerMenu } from "react-icons/rx";

const Sidebar = () => {
    return (
        <aside className='w-1/6 bg-white border-e-2 px-4 py-8 flex flex-col justify-between'>
            <div>
                <img src={instagramLogo} alt="Main logo" width={150}/>
                <ul className="flex flex-col mt-10">
                    <li className="flex flex-row items-center gap-3 text-slate-800 hover:bg-gray-50 py-4 px-1">
                        <GoHomeFill size={30}/>
                        <span className="text-lg font-bold">Home</span>
                    </li>
                    <li className="flex flex-row items-center gap-3 text-slate-800 hover:bg-gray-50 py-4 px-1">
                        <IoSearchOutline size={30} />
                        <span className="text-lg">Search</span>
                    </li>
                    <li className="flex flex-row items-center gap-3 text-slate-800 hover:bg-gray-50 py-4 px-1">
                        <LuCompass size={30} />
                        <span className="text-lg">Explore</span>
                    </li>
                    <li className="flex flex-row items-center gap-3 text-slate-800 hover:bg-gray-50 py-4 px-1">
                        <RiMessengerLine size={30} />
                        <span className="text-lg">Messages</span>
                    </li>
                    <li className="flex flex-row items-center gap-3 text-slate-800 hover:bg-gray-50 py-4 px-1">
                        <IoMdHeartEmpty size={30} />
                        <span className="text-lg">Notifications</span>
                    </li>
                    <li className="flex flex-row items-center gap-3 text-slate-800 hover:bg-gray-50 py-4 px-1">
                        <TbSquareRoundedPlus size={30} />
                        <span className="text-lg">Create</span>
                    </li>
                    <li className="flex flex-row items-center gap-3 text-slate-800 hover:bg-gray-50 py-4 px-1">
                        <div className="w-[30px] h-[30px] bg-slate-800 rounded-full"></div>
                        <span className="text-lg">Profile</span>
                    </li>
                </ul>
            </div>
            <div className="flex flex-row items-center gap-3 text-slate-800 ms-1 hover:bg-gray-50 py-4 px-1">
                <RxHamburgerMenu size={30} />
                <span className="text-lg">Profile</span>
            </div>

        </aside> 
    );
}

export default Sidebar;