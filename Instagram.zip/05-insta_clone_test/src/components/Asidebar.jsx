import pp1 from "../assets/pp_1.jpg"
import pp2 from "../assets/pp_2.jpg"
import pp3 from "../assets/pp_3.jpg"
import pp4 from "../assets/pp_4.jpg"
import pp5 from "../assets/pp_5.jpg"
import pp6 from "../assets/pp_6.jpg"

const Asidebar = () => {
    return (
        <div className='w-1/3 pt-16'>
            <div className="w-3/5 flex flex-col gap-4">
                {/* Main Profile Switch */}
                <div className="flex flex-row justify-between items-center">
                    <div className="flex flex-row gap-6 items-center">
                        <img 
                            src={pp1} 
                            className="rounded-full ring ring-offset-2 ring-gray-300" 
                            width={70} 
                            alt="Profile picture image" 
                        />
                        <div className="flex flex-col">
                            <span className="font-bold">calvarystp</span>
                            <span className="text-gray-400">C A L V A R Y S T . P E T E</span>
                        </div>
                    </div>
                    <span className="font-bold text-sky-500">Switch</span>
                </div>

                {/* Suggestions */}
                <div className="flex flex-row justify-between">
                    <span className="font-bold text-gray-400">Suggestions For You</span>
                    <span className="font-bold">See All</span>
                </div>

                {/* List of suggestions */}
                <div className="flex flex-col gap-3">
                    <div className="flex flex-row justify-between items-center">
                        <div className="flex flex-row gap-6 items-center">
                            <img 
                                src={pp2} 
                                className="rounded-full" 
                                width={40} 
                                alt="Profile picture image" 
                            />
                            <div className="flex flex-col">
                                <span className="font-bold">cthurmanrea</span>
                                <span className="text-gray-400 text-sm">Followed by theoriginallavery</span>
                            </div>
                        </div>
                        <span className="font-bold text-sky-500">Follow</span>
                    </div>
                    <div className="flex flex-row justify-between items-center">
                        <div className="flex flex-row gap-6 items-center">
                            <img 
                                src={pp3} 
                                className="rounded-full" 
                                width={40} 
                                alt="Profile picture image" 
                            />
                            <div className="flex flex-col">
                                <span className="font-bold">border_wulf</span>
                                <span className="text-gray-400 text-sm">Followed by daniellharris95 + 6 more</span>
                            </div>
                        </div>
                        <span className="font-bold text-sky-500">Follow</span>
                    </div>
                    <div className="flex flex-row justify-between items-center">
                        <div className="flex flex-row gap-6 items-center">
                            <img 
                                src={pp4} 
                                className="rounded-full" 
                                width={40} 
                                alt="Profile picture image" 
                            />
                            <div className="flex flex-col">
                                <span className="font-bold">amazinglegendkun</span>
                                <span className="text-gray-400 text-sm">Suggested for you</span>
                            </div>
                        </div>
                        <span className="font-bold text-sky-500">Follow</span>
                    </div>
                    <div className="flex flex-row justify-between items-center">
                        <div className="flex flex-row gap-6 items-center">
                            <img 
                                src={pp5} 
                                className="rounded-full" 
                                width={40} 
                                alt="Profile picture image" 
                            />
                            <div className="flex flex-col">
                                <span className="font-bold">the_first_turtle</span>
                                <span className="text-gray-400 text-sm">Followed by callie.marolf + 3 more</span>
                            </div>
                        </div>
                        <span className="font-bold text-sky-500">Follow</span>
                    </div>
                    <div className="flex flex-row justify-between items-center">
                        <div className="flex flex-row gap-6 items-center">
                            <img 
                                src={pp6} 
                                className="rounded-full" 
                                width={40} 
                                alt="Profile picture image" 
                            />
                            <div className="flex flex-col">
                                <span className="font-bold">didagus.fb</span>
                                <span className="text-gray-400 text-sm">Followed by asian__diaz + 5 more</span>
                            </div>
                        </div>
                        <span className="font-bold text-sky-500">Follow</span>
                    </div>
                </div>
            </div>
        </div> 
    )
}

export default Asidebar;