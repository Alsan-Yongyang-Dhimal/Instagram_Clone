import pp3 from "../assets/pp_3.jpg";
import pp7 from "../assets/pp_7.jpg";
import pp8 from "../assets/pp_8.jpg";
import pp9 from "../assets/pp_9.jpg";
import pp10 from "../assets/pp_10.jpg";
import pp11 from "../assets/pp_11.jpg";
import post from "../assets/post.jpg";

import { HiOutlineDotsHorizontal } from "react-icons/hi";
import { FiMessageCircle } from "react-icons/fi";
import { TbSend } from "react-icons/tb";
import { FaRegBookmark, FaRegHeart } from "react-icons/fa";
import { GoSmiley } from "react-icons/go";

const Content = () => {
    return (
        <section className="grow flex flex-row justify-end pt-10 pe-10">
            <div className="w-2/3 flex flex-col gap-5">
                {/* Story section */}
                <section className="px-3 py-4 border rounded-lg flex flex-row gap-3">
                    <div className="flex flex-col">
                        <div className="rounded-full bg-gradient-to-tr p-[3px] from-yellow-500 from-20% via-red-600 via-40% to-purple-700 to-70%">
                            <div className="rounded-full bg-white p-[.25px]">
                                <img 
                                    src={pp7} 
                                    alt="Story profile image" 
                                    width={80} 
                                    className="rounded-full p-1" 
                                />
                            </div>
                        </div>
                        <span className="text-gray-700">jonathan_...</span>
                    </div>
                    <div className="flex flex-col">
                        <div className="rounded-full bg-gradient-to-tr p-[3px] from-yellow-500 from-20% via-red-600 via-40% to-purple-700 to-70%">
                            <div className="rounded-full bg-white p-[.25px]">
                                <img 
                                    src={pp8} 
                                    alt="Story profile image" 
                                    width={80} 
                                    className="rounded-full p-1" 
                                />
                            </div>
                        </div>
                        <span className="text-gray-700">johnyolth...</span>
                    </div>
                    <div className="flex flex-col">
                        <div className="rounded-full bg-gradient-to-tr p-[3px] from-yellow-500 from-20% via-red-600 via-40% to-purple-700 to-70%">
                            <div className="rounded-full bg-white p-[.25px]">
                                <img 
                                    src={pp9} 
                                    alt="Story profile image" 
                                    width={80} 
                                    className="rounded-full p-1" 
                                />
                            </div>
                        </div>
                        <span className="text-gray-700">calvaryma...</span>
                    </div>
                    <div className="flex flex-col">
                        <div className="rounded-full bg-gradient-to-tr p-[3px] from-yellow-500 from-20% via-red-600 via-40% to-purple-700 to-70%">
                            <div className="rounded-full bg-white p-[.25px]">
                                <img 
                                    src={pp10} 
                                    alt="Story profile image" 
                                    width={80} 
                                    className="rounded-full p-1" 
                                />
                            </div>
                        </div>
                        <span className="text-gray-700">theorigina...</span>
                    </div>
                    <div className="flex flex-col">
                        <div className="rounded-full bg-gradient-to-tr p-[3px] from-yellow-500 from-20% via-red-600 via-40% to-purple-700 to-70%">
                            <div className="rounded-full bg-white p-[.25px]">
                                <img 
                                    src={pp11} 
                                    alt="Story profile image" 
                                    width={80} 
                                    className="rounded-full p-1" 
                                />
                            </div>
                        </div>
                        <span className="text-gray-700">thejakema...</span>
                    </div>
                    <div className="flex flex-col">
                        <div className="rounded-full bg-gradient-to-tr p-[3px] from-yellow-500 from-20% via-red-600 via-40% to-purple-700 to-70%">
                            <div className="rounded-full bg-white p-[.25px]">
                                <img 
                                    src={pp3} 
                                    alt="Story profile image" 
                                    width={80} 
                                    className="rounded-full p-1" 
                                />
                            </div>
                        </div>
                        <span className="text-gray-700">calvarycla...</span>
                    </div>
                </section>

                {/* Posts Section */}
                <section className="border rounded-lg flex flex-col">
                    {/* Header */}
                    <div className="flex flex-row justify-between items-center px-3 py-4 ">
                        <div className="flex flex-row items-center gap-3">
                            <div className="rounded-full bg-gradient-to-tr p-[3px] from-yellow-500 from-20% via-red-600 via-40% to-purple-700 to-70%">
                                <div className="rounded-full bg-white p-[.25px]">
                                    <img 
                                        src={pp10} 
                                        alt="Story profile image" 
                                        width={40} 
                                        className="rounded-full p-1" 
                                    />
                                </div>
                            </div>
                            <span className="font-bold text-lg">calvarymagazine</span>
                        </div>
                        <HiOutlineDotsHorizontal size={25} />
                    </div>

                    {/* Image */}
                    <img 
                        src={post}
                        alt="Post Image"
                        className="object-cover h-96"
                    />

                    {/* Actions */}
                    <div className="flex flex-row justify-between px-3 py-4">
                        <div className="flex flex-row gap-4">
                            <FaRegHeart size={30}/>
                            <FiMessageCircle size={30} className="-rotate-90"/>
                            <TbSend size={30}/>
                        </div>
                        <FaRegBookmark size={30}/>
                    </div>

                    {/* Liked by */}
                    <div className="flex flex-row gap-3 px-3">
                        <img 
                            src={pp9} 
                            className="rounded-full z-10 ring-2 ring-white" 
                            width={25} 
                            alt="Profile picture image" 
                        />
                        <img 
                            src={pp10} 
                            className="rounded-full absolute translate-x-4 z-0" 
                            width={25} 
                            alt="Profile picture image" 
                        />
                        <span className="ps-3">
                            Liked by 
                            <span className="font-bold"> calvarymv </span>
                            and <span className="font-bold"> others</span>
                        </span>
                    </div>
                    <div className="px-3 py-1 flex flex-col gap-2">
                        <span>
                            <span className="font-bold">calvarymagazine</span>
                            <span> AS IRON SHARPENS IRON ~ SOCAL MEN'S CONFERENCE Eight thousan men attended the free event at the Anaheim Convention... <span className="text-gray-400">more</span></span>
                        </span>
                        <span className="text-gray-400">View all 7 comments</span>
                        <span className="text-gray-300 text-xs">3 DAYS AGO</span>
                    </div>

                    {/* Add Comment */}
                    <div className="border-t px-3 py-4 mt-2 flex flex-row justify-between">
                        <div className="flex flex-row gap-6 items-center">
                            <GoSmiley size={30}/>
                            <span className="text-gray-400">
                                Add a comment...
                            </span>
                        </div>
                        <span className="text-blue-500/50 font-bold">Post</span>
                    </div>
                </section>
            </div>
        </section>
    )
}

export default Content;