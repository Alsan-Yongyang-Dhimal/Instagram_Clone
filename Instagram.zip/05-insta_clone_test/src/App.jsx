import Sidebar from "./components/Sidebar";
import Asidebar from "./components/Asidebar";
import Content from "./components/Content";

const App = () => {
    return (
        <main className="bg-slate-50 h-screen flex flex-row">
            <Sidebar />
            <Content />
            <Asidebar />
        </main>
    )
}

export default App;